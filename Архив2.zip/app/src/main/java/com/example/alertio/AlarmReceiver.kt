package com.example.alertio

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Get alarm details from intent
        val alarmId = intent.getIntExtra("ALARM_ID", 0)
        val title = intent.getStringExtra("TITLE") ?: "Напоминание"
        val description = intent.getStringExtra("DESCRIPTION") ?: "Пора выполнить задачу!"

        // Get notification manager service
        val notificationManager = 
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create notification channel for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelDescription = "Канал для уведомлений о задачах"
            val channel = NotificationChannel(
                "task_channel",
                "Задачи",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setDescription(channelDescription)
                enableVibration(true)
                enableLights(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Build and show notification
        val notification = NotificationCompat.Builder(context, "task_channel")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(description)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        notificationManager.notify(alarmId, notification)
    }
}
