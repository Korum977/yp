package com.example.alertio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.alertio.data.TaskEntity
import com.example.alertio.viewmodel.TaskViewModel
import java.util.*
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val alarmScheduler = AlarmScheduler()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            val viewModel: TaskViewModel = viewModel()
            var showDialog by remember { mutableStateOf(false) }
            val tasks by viewModel.allTasks.collectAsState(initial = emptyList())
            
            MaterialTheme {
                Scaffold(
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showDialog = true }) {
                            Text("+")
                        }
                    }
                ) { padding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(16.dp)
                    ) {
                        tasks.forEach { task ->
                            TaskItem(
                                task = task,
                                onDelete = { 
                                    alarmScheduler.cancelAlarm(this@MainActivity, task.id)
                                    viewModel.deleteTask(task)
                                }
                            )
                        }
                    }
                    
                    if (showDialog) {
                        AddTaskDialog(
                            onDismiss = { showDialog = false },
                            onTaskAdded = { title, description, dateTime ->
                                val newTask = TaskEntity(
                                    title = title,
                                    description = description,
                                    dateTime = dateTime
                                )
                                viewModel.insertTask(newTask)
                                alarmScheduler.setAlarm(
                                    context = this@MainActivity,
                                    alarmId = newTask.id,
                                    timeInMillis = newTask.dateTime,
                                    title = newTask.title,
                                    description = newTask.description
                                )
                                showDialog = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TaskItem(
    task: TaskEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(text = task.title, style = MaterialTheme.typography.titleMedium)
            Text(text = task.description, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "Дата: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(task.dateTime))}",
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = onDelete) {
                Text("Удалить")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateTimePicker(
    onDateTimeSelected: (Long) -> Unit
) {
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    
    val calendar = Calendar.getInstance()
    
    var selectedYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
    var selectedMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
    var selectedDay by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }
    var selectedHour by remember { mutableStateOf(calendar.get(Calendar.HOUR_OF_DAY)) }
    var selectedMinute by remember { mutableStateOf(calendar.get(Calendar.MINUTE)) }
    
    // Функция для проверки валидности выбранной даты/времени
    fun isValidDateTime(): Boolean {
        val selectedCalendar = Calendar.getInstance().apply {
            set(selectedYear, selectedMonth, selectedDay, selectedHour, selectedMinute, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return selectedCalendar.timeInMillis > System.currentTimeMillis()
    }

    Column {
        Button(onClick = { showDatePicker = true }) {
            Text("Выбрать дату: $selectedDay/${selectedMonth + 1}/$selectedYear")
        }
        
        Button(onClick = { showTimePicker = true }) {
            Text("Выбрать время: ${String.format("%02d:%02d", selectedHour, selectedMinute)}")
        }

        val selectedCalendar = Calendar.getInstance().apply {
            set(selectedYear, selectedMonth, selectedDay, selectedHour, selectedMinute, 0)
            set(Calendar.MILLISECOND, 0)
        }
        
        if (isValidDateTime()) {
            Text(
                "Напоминание будет показано: " +
                SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                    .format(selectedCalendar.time),
                color = MaterialTheme.colorScheme.primary
            )
            // Вызываем callback только если дата валидна
            onDateTimeSelected(selectedCalendar.timeInMillis)
        } else {
            Text("Выберите будущую дату", color = MaterialTheme.colorScheme.error)
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = Calendar.getInstance().timeInMillis
        )
        
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { selectedDateMillis ->
                            val newDate = Calendar.getInstance().apply {
                                timeInMillis = selectedDateMillis
                            }
                            selectedYear = newDate.get(Calendar.YEAR)
                            selectedMonth = newDate.get(Calendar.MONTH)
                            selectedDay = newDate.get(Calendar.DAY_OF_MONTH)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Отмена")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (showTimePicker) {
        val timePickerState = rememberTimePickerState(
            initialHour = selectedHour,
            initialMinute = selectedMinute
        )
        
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        selectedHour = timePickerState.hour
                        selectedMinute = timePickerState.minute
                        showTimePicker = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Отмена")
                }
            },
            text = {
                TimePicker(state = timePickerState)
            }
        )
    }
}

@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onTaskAdded: (String, String, Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dateTimeInMillis by remember { mutableStateOf(0L) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить задачу") },
        text = {
            Column {
                TextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название") }
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Описание") }
                )
                Spacer(modifier = Modifier.height(16.dp))
                DateTimePicker { millis ->
                    dateTimeInMillis = millis
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (dateTimeInMillis > 0) {
                        onTaskAdded(title, description, dateTimeInMillis)
                    }
                },
                enabled = title.isNotBlank() && dateTimeInMillis > 0
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
