package com.example.timerio.ui

import android.os.CountDownTimer
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import android.content.Context
import com.example.timerio.data.TimerPreferences
import kotlinx.coroutines.launch

class TimerViewModel(
    private val timerPreferences: TimerPreferences
) : ViewModel() {
    
    private var timer: CountDownTimer? = null
    
    var timeLeft = mutableStateOf(0L)
        private set
        
    var isRunning = mutableStateOf(false)
        private set

    init {
        // Загружаем сохраненное состояние при создании ViewModel
        loadSavedState()
    }

    private fun loadSavedState() {
        timeLeft.value = timerPreferences.loadTimerState()
    }

    fun startTimer(timeInMillis: Long, onFinish: () -> Unit) {
        timer?.cancel() // Отменяем старый таймер, если он был
        
        timeLeft.value = timeInMillis
        isRunning.value = true
        
        timer = object : CountDownTimer(timeInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft.value = millisUntilFinished
                // Сохраняем состояние при каждом тике
                viewModelScope.launch {
                    timerPreferences.saveTimerState(millisUntilFinished)
                }
            }

            override fun onFinish() {
                isRunning.value = false
                timeLeft.value = 0
                timerPreferences.saveTimerState(0)
                onFinish()
            }
        }.start()
    }

    fun cancelTimer() {
        timer?.cancel()
        timer = null
        isRunning.value = false
        timeLeft.value = 0
        timerPreferences.saveTimerState(0)
    }

    override fun onCleared() {
        super.onCleared()
        timer?.cancel()
    }

    fun saveState() {
        timerPreferences.saveTimerState(timeLeft.value)
    }
}

// Factory для создания ViewModel с зависимостями
class TimerViewModelFactory(
    private val context: Context
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TimerViewModel::class.java)) {
            return TimerViewModel(TimerPreferences(context)) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
