package com.example.timerio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.timerio.ui.TimerScreen
import com.example.timerio.ui.TimerViewModel
import com.example.timerio.ui.TimerViewModelFactory
import com.example.timerio.ui.theme.TimerioTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: TimerViewModel by viewModels { 
        TimerViewModelFactory(applicationContext) 
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            TimerioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TimerScreen(viewModel)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Сохраняем состояние при сворачивании приложения
        lifecycleScope.launch {
            if (viewModel.isRunning.value) {
                // Сохраняем только если таймер активен
                viewModel.saveState()
            }
        }
    }
}
