package com.example.timerio.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextAlign
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerScreen(viewModel: TimerViewModel) {
    var inputTime by remember { mutableStateOf("") }
    var isMinutesSelected by remember { mutableStateOf(true) }
    val context = LocalContext.current
    val timeLeft by viewModel.timeLeft
    val isRunning by viewModel.isRunning

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!isRunning) {
            // Переключатель единиц времени
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                FilterChip(
                    selected = isMinutesSelected,
                    onClick = { isMinutesSelected = true },
                    label = { Text("Минуты") },
                    modifier = Modifier.padding(end = 8.dp)
                )
                FilterChip(
                    selected = !isMinutesSelected,
                    onClick = { isMinutesSelected = false },
                    label = { Text("Секунды") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Поле для ввода времени
            TextField(
                value = inputTime,
                onValueChange = { if (it.length <= 3) inputTime = it.filter { char -> char.isDigit() } },
                label = { Text(if (isMinutesSelected) "Введите время в минутах" else "Введите время в секундах") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Кнопка запуска таймера
            Button(
                onClick = {
                    val time = inputTime.toLongOrNull()
                    if (time != null && time > 0) {
                        val timeInMillis = if (isMinutesSelected) {
                            time * 60 * 1000 // конвертация минут в миллисекунды
                        } else {
                            time * 1000 // конвертация секунд в миллисекунды
                        }
                        viewModel.startTimer(
                            timeInMillis = timeInMillis,
                            onFinish = {
                                Toast.makeText(
                                    context,
                                    "Таймер завершен!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                        inputTime = ""
                    }
                },
                enabled = inputTime.isNotEmpty()
            ) {
                Text("Запустить таймер")
            }
        } else {
            // Отображение оставшегося времени
            Text(
                text = formatTime(timeLeft),
                style = MaterialTheme.typography.headlineLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(16.dp)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Кнопка отмены таймера
            Button(
                onClick = { viewModel.cancelTimer() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Отменить")
            }
        }
    }
}

private fun formatTime(timeInMillis: Long): String {
    val minutes = TimeUnit.MILLISECONDS.toMinutes(timeInMillis)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(timeInMillis) % 60
    return String.format("%02d:%02d", minutes, seconds)
}
