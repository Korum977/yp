package com.example.timerio.data

import android.content.Context
import android.content.SharedPreferences

class TimerPreferences(context: Context) {
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences(TIMER_PREFERENCES, Context.MODE_PRIVATE)

    fun saveTimerState(timeLeft: Long) {
        sharedPreferences.edit().apply {
            putLong(KEY_TIME_LEFT, timeLeft)
            apply()
        }
    }

    fun loadTimerState(): Long {
        return sharedPreferences.getLong(KEY_TIME_LEFT, 0L)
    }

    companion object {
        private const val TIMER_PREFERENCES = "timer_prefs"
        private const val KEY_TIME_LEFT = "time_left"
    }
}
