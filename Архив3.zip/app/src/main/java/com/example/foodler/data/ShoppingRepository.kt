package com.example.foodler.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import com.example.foodler.model.ShoppingItem

class ShoppingRepository(private val shoppingDao: ShoppingDao) {
    val allItems: Flow<List<ShoppingItem>> = shoppingDao.getAllItems()
        .map { items -> items.map { it.toShoppingItem() } }

    suspend fun insertItem(item: ShoppingItem) {
        shoppingDao.insertItem(item.toEntity())
    }

    suspend fun deleteItem(item: ShoppingItem) {
        shoppingDao.deleteItem(item.toEntity())
    }

    suspend fun updateItem(item: ShoppingItem) {
        shoppingDao.updateItem(item.toEntity())
    }
}
