package com.example.foodler.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.foodler.model.ShoppingItem
import com.example.foodler.model.SortType
import com.example.foodler.viewmodel.ShoppingListViewModel

@Composable
fun ShoppingListScreen(
    viewModel: ShoppingListViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Добавляем меню сортировки
        SortMenu(
            currentSort = viewModel.sortType.value,
            onSortChange = { viewModel.changeSortType(it) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        AddItemSection(
            value = viewModel.newItemName.value,
            onValueChange = { viewModel.updateNewItemName(it) },
            onAddClick = {
                if (viewModel.editingItem.value != null) {
                    viewModel.updateItem()
                } else {
                    viewModel.addItem(viewModel.newItemName.value)
                }
            },
            isEditing = viewModel.editingItem.value != null,
            onCancelEdit = { viewModel.cancelEditing() }
        )

        Spacer(modifier = Modifier.height(16.dp))

        ShoppingList(
            items = viewModel.items.value,
            onCheckedChange = { viewModel.toggleItemCheck(it) },
            onDeleteClick = { viewModel.removeItem(it) },
            onEditClick = { viewModel.startEditing(it) }
        )
    }
}

@Composable
fun SortMenu(
    currentSort: SortType,
    onSortChange: (SortType) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Default.Sort, "Сортировка")
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text("По алфавиту") },
                onClick = { 
                    onSortChange(SortType.NAME)
                    expanded = false
                }
            )
            DropdownMenuItem(
                text = { Text("По дате добавления") },
                onClick = { 
                    onSortChange(SortType.CREATED)
                    expanded = false
                }
            )
            DropdownMenuItem(
                text = { Text("По статусу") },
                onClick = { 
                    onSortChange(SortType.CHECKED)
                    expanded = false
                }
            )
        }
    }
}

@Composable
fun AddItemSection(
    value: String,
    onValueChange: (String) -> Unit,
    onAddClick: () -> Unit,
    isEditing: Boolean,
    onCancelEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            label = { Text(if (isEditing) "Редактировать товар" else "Добавить товар") },
            singleLine = true
        )
        Spacer(modifier = Modifier.width(8.dp))
        if (isEditing) {
            IconButton(onClick = onCancelEdit) {
                Icon(Icons.Default.Delete, "Отменить")
            }
        }
        IconButton(onClick = onAddClick) {
            Icon(
                if (isEditing) Icons.Default.Edit else Icons.Default.Add,
                if (isEditing) "Сохранить" else "Добавить"
            )
        }
    }
}

@Composable
fun ShoppingList(
    items: List<ShoppingItem>,
    onCheckedChange: (ShoppingItem) -> Unit,
    onDeleteClick: (ShoppingItem) -> Unit,
    onEditClick: (ShoppingItem) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items) { item ->
            ShoppingItemRow(
                item = item,
                onCheckedChange = { onCheckedChange(item) },
                onDeleteClick = { onDeleteClick(item) },
                onEditClick = { onEditClick(item) }
            )
        }
    }
}

@Composable
fun ShoppingItemRow(
    item: ShoppingItem,
    onCheckedChange: () -> Unit,
    onDeleteClick: () -> Unit,
    onEditClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = item.isChecked,
                    onCheckedChange = { onCheckedChange() }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            Row {
                IconButton(onClick = onEditClick) {
                    Icon(Icons.Default.Edit, "Редактировать")
                }
                IconButton(onClick = onDeleteClick) {
                    Icon(Icons.Default.Delete, "Удалить")
                }
            }
        }
    }
}
