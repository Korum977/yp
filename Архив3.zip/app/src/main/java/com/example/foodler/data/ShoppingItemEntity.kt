package com.example.foodler.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.foodler.model.ShoppingItem
import java.util.Date

@Entity(tableName = "shopping_items")
data class ShoppingItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val quantity: Int,
    val isChecked: Boolean,
    val createdAt: Long
) {
    fun toShoppingItem(): ShoppingItem {
        return ShoppingItem(
            id = id,
            name = name,
            quantity = quantity,
            isChecked = isChecked,
            createdAt = Date(createdAt)
        )
    }
}

fun ShoppingItem.toEntity(): ShoppingItemEntity {
    return ShoppingItemEntity(
        id = id,
        name = name,
        quantity = quantity,
        isChecked = isChecked,
        createdAt = createdAt.time
    )
}
