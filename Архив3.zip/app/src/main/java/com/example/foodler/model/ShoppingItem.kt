package com.example.foodler.model

import java.util.Date

data class ShoppingItem(
    val id: Int = 0,
    val name: String,
    val quantity: Int = 1,
    val isChecked: Boolean = false,
    val createdAt: Date = Date()  // Добавляем дату создания
)
