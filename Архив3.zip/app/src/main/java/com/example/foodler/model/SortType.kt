package com.example.foodler.model

enum class SortType {
    NAME, CREATED, CHECKED
}
