package com.example.foodler.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.State
import com.example.foodler.model.ShoppingItem
import com.example.foodler.model.SortType
import com.example.foodler.data.ShoppingDatabase
import com.example.foodler.data.ShoppingRepository
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ShoppingListViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ShoppingRepository
    
    // Состояние для списка покупок
    private val _items = mutableStateOf<List<ShoppingItem>>(emptyList())
    val items: State<List<ShoppingItem>> = _items

    // Состояние для поля ввода нового товара
    private val _newItemName = mutableStateOf("")
    val newItemName: State<String> = _newItemName

    // Состояние для редактирования
    private val _editingItem = mutableStateOf<ShoppingItem?>(null)
    val editingItem: State<ShoppingItem?> = _editingItem

    // Состояние для типа сортировки
    private val _sortType = mutableStateOf(SortType.CREATED)
    val sortType: State<SortType> = _sortType

    init {
        val database = ShoppingDatabase.getDatabase(application)
        repository = ShoppingRepository(database.shoppingDao())
        
        // Наблюдаем за изменениями в базе данных
        viewModelScope.launch {
            repository.allItems.collect { newItems ->
                _items.value = sortItems(newItems)
            }
        }
    }

    fun updateNewItemName(name: String) {
        _newItemName.value = name
    }

    fun addItem(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertItem(
                ShoppingItem(
                    name = name.trim()
                )
            )
        }
        _newItemName.value = ""
    }

    fun removeItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.deleteItem(item)
        }
    }

    fun updateItem() {
        val editingItem = _editingItem.value ?: return
        viewModelScope.launch {
            repository.updateItem(
                editingItem.copy(name = _newItemName.value.trim())
            )
        }
        cancelEditing()
    }

    fun toggleItemCheck(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isChecked = !item.isChecked))
        }
    }

    // Новые функции для редактирования
    fun startEditing(item: ShoppingItem) {
        _editingItem.value = item
        _newItemName.value = item.name
    }

    fun cancelEditing() {
        _editingItem.value = null
        _newItemName.value = ""
    }

    // Функции для сортировки
    fun changeSortType(type: SortType) {
        _sortType.value = type
        _items.value = sortItems(_items.value)
    }

    private fun sortItems(items: List<ShoppingItem>): List<ShoppingItem> {
        return when (_sortType.value) {
            SortType.NAME -> items.sortedBy { it.name }
            SortType.CREATED -> items.sortedBy { it.createdAt }
            SortType.CHECKED -> items.sortedBy { it.isChecked }
        }
    }
}
