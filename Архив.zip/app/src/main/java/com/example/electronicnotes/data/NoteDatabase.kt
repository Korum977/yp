package com.example.electronicnotes.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.electronicnotes.data.Note
import com.example.electronicnotes.data.NoteDao

// Определение базы данных с помощью аннотации @Database
@Database(entities = [Note::class], version = 2, exportSchema = false)
@TypeConverters(Converters::class)
abstract class NoteDatabase : RoomDatabase() {
    // Абстрактная функция для получения объекта NoteDao
    abstract fun noteDao(): NoteDao

    // Компаньон-объект для доступа к базе данных
    companion object {
        // Волатильная переменная для хранения единственного экземпляра базы данных
        @Volatile
        private var INSTANCE: NoteDatabase? = null

        // Функция для получения экземпляра базы данных
        fun getDatabase(context: Context): NoteDatabase {
            // Если экземпляр базы данных уже существует, возвращаем его
            return INSTANCE ?: synchronized(this) {
                // Если экземпляр базы данных еще не создан, создаем его
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NoteDatabase::class.java,
                    "note_database"
                )
                .fallbackToDestructiveMigration() // При изменении схемы БД пересоздаст её
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
