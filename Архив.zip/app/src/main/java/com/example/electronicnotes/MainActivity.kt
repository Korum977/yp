package com.example.electronicnotes

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.electronicnotes.data.Note
import com.example.electronicnotes.data.NoteDatabase
import com.example.electronicnotes.ui.screens.AddEditNoteScreen
import com.example.electronicnotes.ui.screens.NotesListScreen
import com.example.electronicnotes.ui.theme.ElectronicNotesTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    @SuppressLint("StateFlowValueCalledInComposition")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val database = NoteDatabase.getDatabase(this)
        val noteDao = database.noteDao()

        setContent {
            val navController = rememberNavController()
            var notes by remember { mutableStateOf<List<Note>>(emptyList()) }
            
            // Собираем Flow из базы данных
            LaunchedEffect(Unit) {
                noteDao.getAllNotes().collectLatest { notesList ->
                    notes = notesList
                }
            }
            
            ElectronicNotesTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = "notes_list"
                    ) {
                        composable("notes_list") {
                            NotesListScreen(
                                notes = notes,
                                onAddNote = {
                                    navController.navigate("add_edit_note")
                                },
                                onNoteClick = { note ->
                                    navController.navigate("add_edit_note?noteId=${note.id}")
                                },
                                noteDao = noteDao
                            )
                        }

                        composable(
                            route = "add_edit_note?noteId={noteId}",
                            arguments = listOf(
                                navArgument("noteId") {
                                    type = NavType.IntType
                                    defaultValue = -1
                                }
                            )
                        ) { backStackEntry ->
                            val noteId = backStackEntry.arguments?.getInt("noteId") ?: -1
                            val existingNote = notes.find { it.id == noteId }

                            AddEditNoteScreen(
                                noteDao = noteDao,
                                existingNote = existingNote,
                                onNoteSaved = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
