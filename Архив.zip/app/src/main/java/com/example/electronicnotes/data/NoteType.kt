package com.example.electronicnotes.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class NoteType(
    val icon: ImageVector,
    val label: String
) {
    TASK(Icons.Default.CheckBox, "Задача"),
    IDEA(Icons.Default.EmojiObjects, "Идея"),
    SHOPPING(Icons.Default.ShoppingCart, "Покупки"),
    WORK(Icons.Default.Work, "Работа"),
    PERSONAL(Icons.Default.Person, "Личное"),
    HEALTH(Icons.Default.Favorite, "Здоровье"),
    TRAVEL(Icons.Default.Flight, "Путешествия"),
    STUDY(Icons.Default.School, "Учеба"),
    FINANCE(Icons.Default.AttachMoney, "Финансы"),
    OTHER(Icons.Default.Description, "Другое")
}
