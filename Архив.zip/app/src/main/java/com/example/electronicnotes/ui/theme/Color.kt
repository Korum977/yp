package com.example.electronicnotes.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

// Основная палитра
val Primary = Color(0xFF9C235D)        // Основной цвет (розовый)
val Secondary = Color(0xFFB95E96)      // Вторичный цвет (светло-розовый)
val Tertiary = Color(0xFF5B1A36)       // Третичный цвет (бордовый)

// Фоновые цвета
val LightBackground = Color(0xFFF0F5F6)  // Светлый фон
val DarkBackground = Color(0xFF171315)   // Тёмный фон
val SurfaceLight = Color(0xFFFFFFFF)     // Поверхность светлая
val SurfaceDark = Color(0xFF2D2D2D)      // Поверхность тёмная

// Акцентные цвета
val AccentSuccess = Color(0xFF4CAF50)    // Зеленый для успешных действий
val AccentError = Color(0xFFE53935)      // Красный для ошибок
val AccentWarning = Color(0xFFFFA726)    // Оранжевый для предупреждений

// Цвета текста
val TextPrimaryLight = Color(0xFF000000)
val TextSecondaryLight = Color(0xFF666666)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFAAAAAA)

// Цвета для типов заметок
val TaskColor = Color(0xFF4CAF50)        // Зеленый для задач
val IdeaColor = Color(0xFFFFEB3B)        // Желтый для идей
val ShoppingColor = Color(0xFF2196F3)    // Синий для покупок
val WorkColor = Color(0xFFFF9800)        // Оранжевый для работы
val PersonalColor = Color(0xFF9C27B0)    // Фиолетовый для личного
val HealthColor = Color(0xFFE91E63)      // Розовый для здоровья
val TravelColor = Color(0xFF00BCD4)      // Голубой для путешествий
val StudyColor = Color(0xFF3F51B5)       // Индиго для учебы
val FinanceColor = Color(0xFF4CAF50)     // Зеленый для финансов
val OtherColor = Color(0xFF9E9E9E)       // Серый для прочего

// Светлая тема
val LightColorScheme = lightColorScheme(
    primary = Primary,
    secondary = Secondary,
    tertiary = Tertiary,
    background = LightBackground,
    surface = SurfaceLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    error = AccentError,
    onError = Color.White
)

// Темная тема
val DarkColorScheme = darkColorScheme(
    primary = Primary,
    secondary = Secondary,
    tertiary = Tertiary,
    background = DarkBackground,
    surface = SurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    error = AccentError,
    onError = Color.White
)

// Цветовые схемы для типов заметок
val NoteTypeColors = mapOf(
    "TASK" to TaskColor,
    "IDEA" to IdeaColor,
    "SHOPPING" to ShoppingColor,
    "WORK" to WorkColor,
    "PERSONAL" to PersonalColor,
    "HEALTH" to HealthColor,
    "TRAVEL" to TravelColor,
    "STUDY" to StudyColor,
    "FINANCE" to FinanceColor,
    "OTHER" to OtherColor
)
